﻿using System;
using System.Windows.Input;

namespace Screens.Commands
{
    public class DelegateCommand : ICommand
    {
        Func<object, bool> canExecute;
        Action<object> execute;
        
        public DelegateCommand()
        {

        }

        public DelegateCommand(Action<object> execute) : this()
        {
            this.execute = execute;
        }
        public DelegateCommand(Action<object> execute, Func<object, bool> canExecute):this(execute)
        {
            this.canExecute = canExecute;
        }

        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            if(this.canExecute != null)
            {
                this.canExecute(parameter);
            }

            return true;
        }

        public void Execute(object parameter)
        {
            if (this.execute != null)
            {
                this.execute(parameter);
            }
        }

        public void RaiseCanExecuteChanged()
        {
            if(this.CanExecuteChanged != null)
            {
                this.CanExecuteChanged(this, new EventArgs());
            }
        }
    }
}
