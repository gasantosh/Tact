﻿using Newtonsoft.Json;
using Screens.Commands;
using Screens.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace Screens.ViewModels
{
    public class StartViewModel : INotifyPropertyChanged
    {
        private ScreenViewModel[] elementViewModels;
        private ScreenViewModel selectedScreenViewModel;
        private bool isLastScreen;
        private int currentIndex;

        public StartViewModel()
        {
            var response = this.ConsumeService();
            this.CreateScreenViewModel(response.Result);
            this.BackCommand = new DelegateCommand(s =>
            {
                if (this.currentIndex == 0) return;

                this.SelectedScreenViewModel = this.elementViewModels[--this.currentIndex];
                this.IsLastScreen = false;
            },
            s =>
            {
                return this.currentIndex > 0;
            });

            this.NextCommand = new DelegateCommand(s =>
            {
                this.SelectedScreenViewModel = this.elementViewModels[++this.currentIndex];
                this.IsLastScreen = this.currentIndex == this.elementViewModels.Length - 1;
            },
            s => this.elementViewModels!= null && this.currentIndex < this.elementViewModels.Length);

            this.FinishCommand = new DelegateCommand(s =>
            {
                var path = @"D:\Work\csc.txt";

                var results = this.elementViewModels.SelectMany(sc => sc.Elements).Select(e => new Result { Id = e.Id, value = e.Value }).ToArray();
                var saveText = JsonConvert.SerializeObject(results);
                if(File.Exists(path))
                {
                    File.Delete(path);
                }

                File.WriteAllText(path, saveText);
            });
        }

        public DelegateCommand BackCommand { get; set; }

        public DelegateCommand NextCommand { get; set; }

        public DelegateCommand FinishCommand { get; set; }

        public ScreenViewModel SelectedScreenViewModel
        {
            get
            {
                return this.selectedScreenViewModel;
            }

            set
            {
                this.selectedScreenViewModel = value;
                this.OnPropertyChanged("SelectedScreenViewModel");
            }
        }

        public bool IsLastScreen
        {
            get
            {
                return this.isLastScreen;
            }

            set
            {
                this.isLastScreen = value;
                this.OnPropertyChanged("IsLastScreen");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void CreateScreenViewModel(IEnumerable<Screen> screens)
        {
            List<ScreenViewModel> svm = new List<ScreenViewModel>();
            foreach(var screen in screens)
            {
                var vm = new ScreenViewModel();
                svm.Add(vm);
                vm.CreateScreenElementsAndLabel(screen);
            }

            this.elementViewModels = svm.ToArray();
            this.SelectedScreenViewModel = this.elementViewModels[0];
            this.currentIndex = 0;
            this.IsLastScreen = this.currentIndex == this.elementViewModels.Length - 1;
        }

        private void OnPropertyChanged(string propName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propName));
            }
        }

        private async Task<IEnumerable<Screen>> ConsumeService()
        {
            try
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://5ddf82bd4a658b0014c48b41.mockapi.io/");

                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    client.Timeout = TimeSpan.FromSeconds(Convert.ToDouble(1000000));

                    HttpResponseMessage response = new HttpResponseMessage();

                    response = await client.GetAsync("api/v1/ui").ConfigureAwait(false);

                  
                    if (response.IsSuccessStatusCode)
                    {
                        string result = response.Content.ReadAsStringAsync().Result;
                        var responseObj = JsonConvert.DeserializeObject<IEnumerable<Screen>>(result);

                        return responseObj;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return new List<Screen>();
        }
    }
}
