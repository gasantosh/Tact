﻿using Screens.Models;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace Screens.ViewModels
{
    public class ScreenViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<ElementViewModel> elements;
        private string label;

        public ScreenViewModel()
        {
            this.Elements = new ObservableCollection<ElementViewModel>();
        }

        public string Label
        {
            get
            {
                return this.label;
            }

            set
            {
                this.label = value;
                this.OnPropertyChanged("Label");
            }
        }

        public ObservableCollection<ElementViewModel> Elements
        {
            get
            {
                return this.elements;
            }

            set
            {
                this.elements = value;
                this.OnPropertyChanged("Elements");
            }
        }

        public void CreateScreenElementsAndLabel(Screen screen)
        {
            this.Label = screen.Label;
            foreach(var element in screen.Elements)
            {
                var elementViewModel = new ElementViewModel();
                this.CreateElements(element, elementViewModel);
                this.Elements.Add(elementViewModel);
            }
        }

        private void CreateElements(Element element, ElementViewModel elementViewModel)
        {
            elementViewModel.Id = element.Id;
            elementViewModel.Type = element.Type;
            elementViewModel.Label = element.Label;
            elementViewModel.Value = element.value;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propName));
            }
        }
    }
}
