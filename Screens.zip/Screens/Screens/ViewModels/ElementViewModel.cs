﻿using Screens.Models;
using System.Collections.Generic;
using System.ComponentModel;

namespace Screens.ViewModels
{
    public class ElementViewModel : INotifyPropertyChanged
    {
        private string id;
        private string type;
        private string label;
        private string value;
        public string Id
        {
            get
            {
                return this.id;
            }

            set
            {
                this.id = value;
                this.OnPropertyChanged("Id");
            }
        }

        public string Type
        {
            get
            {
                return this.type;
            }

            set
            {
                this.type = value;
                this.OnPropertyChanged("Type");
            }
        }

        public string Label
        {
            get
            {
                return this.label;
            }

            set
            {
                this.label = value;
                this.OnPropertyChanged("Label");
            }
        }

        public string Value
        {
            get
            {
                return this.value;
            }

            set
            {
                this.value = value;
                this.OnPropertyChanged("Value");
            }
        }      

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propName)
        {
            if(this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propName));
            }
        }
    }
}
