﻿namespace Screens.Models
{
    public class Element
    {
        public string Id { get; set; }

        public string Type { get; set; }

        public string Label { get; set; }

        public string value { get; set; }
    }
}
