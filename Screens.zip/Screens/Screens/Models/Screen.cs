﻿using System.Collections.Generic;

namespace Screens.Models
{
    public class Screen
    {
        public string Label { get; set; }

        public IEnumerable<Element> Elements { get; set; }
    }
}
