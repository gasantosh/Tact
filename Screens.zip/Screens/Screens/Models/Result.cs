﻿namespace Screens.Models
{
    public class Result
    {
        public string Id { get; set; }

        public string value { get; set; }
    }
}
