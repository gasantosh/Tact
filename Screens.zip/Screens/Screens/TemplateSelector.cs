﻿using Screens.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace Screens
{
    public class TemplateSelector : DataTemplateSelector
    {
        public DataTemplate TextTemplate { get; set; }
        public DataTemplate BoolTemplate { get; set; }
        public DataTemplate NumberTemplate { get; set; }
        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            var itm = (ElementViewModel)item;

            if (itm.Type == "bool")
                return this.BoolTemplate;

            if (itm.Type == "number")
                return this.NumberTemplate;

            if (itm.Type == "text")
                return this.TextTemplate;

            return null;
        }
    }
}
